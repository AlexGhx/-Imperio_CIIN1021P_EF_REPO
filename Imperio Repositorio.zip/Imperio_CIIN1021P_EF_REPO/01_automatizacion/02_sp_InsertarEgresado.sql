USE baseMINSA;
GO

CREATE OR ALTER PROCEDURE sp_InsertarEgresado
    @UUID VARCHAR(100),
    @HISTORIA VARCHAR(100),
    @SEXO VARCHAR(20),
    @EDAD INT,
    @FECHA_INGRESO DATE,
    @FECHA_EGRESO DATE,
    @UBIGEO_LUGAR_RESIDENCIA VARCHAR(20),
    @LUGAR_RESIDENCIA VARCHAR(200),
    @FECHA_CORTE DATE
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        SAVE TRANSACTION PuntoSeguro;

        IF @FECHA_EGRESO < @FECHA_INGRESO
        BEGIN
            ROLLBACK TRANSACTION PuntoSeguro;

            INSERT INTO LogExcepciones
            (
                TablaAfectada,
                UUID,
                ReglaIncumplida,
                Descripcion
            )
            VALUES
            (
                'Egresados',
                @UUID,
                'Fecha de egreso inválida',
                'La fecha de egreso es anterior a la fecha de ingreso.'
            );

            COMMIT TRANSACTION;
            RETURN;
        END;

        IF @EDAD < 0 OR @EDAD > 110
        BEGIN
            ROLLBACK TRANSACTION PuntoSeguro;

            INSERT INTO LogExcepciones
            (
                TablaAfectada,
                UUID,
                ReglaIncumplida,
                Descripcion
            )
            VALUES
            (
                'Egresados',
                @UUID,
                'Edad inválida',
                'La edad debe estar entre 0 y 110 años.'
            );

            COMMIT TRANSACTION;
            RETURN;
        END;

        IF EXISTS
        (
            SELECT 1
            FROM Egresados
            WHERE UUID = @UUID
              AND FECHA_INGRESO = @FECHA_INGRESO
              AND FECHA_EGRESO = @FECHA_EGRESO
        )
        BEGIN
            ROLLBACK TRANSACTION PuntoSeguro;

            INSERT INTO LogExcepciones
            (
                TablaAfectada,
                UUID,
                ReglaIncumplida,
                Descripcion
            )
            VALUES
            (
                'Egresados',
                @UUID,
                'Episodio duplicado',
                'Ya existe un registro con el mismo UUID, fecha de ingreso y fecha de egreso.'
            );

            COMMIT TRANSACTION;
            RETURN;
        END;

        INSERT INTO Egresados
        (
            UUID,
            HISTORIA,
            SEXO,
            EDAD,
            FECHA_INGRESO,
            FECHA_EGRESO,
            UBIGEO_LUGAR_RESIDENCIA,
            LUGAR_RESIDENCIA,
            FECHA_CORTE
        )
        VALUES
        (
            @UUID,
            @HISTORIA,
            @SEXO,
            @EDAD,
            @FECHA_INGRESO,
            @FECHA_EGRESO,
            @UBIGEO_LUGAR_RESIDENCIA,
            @LUGAR_RESIDENCIA,
            @FECHA_CORTE
        );

        COMMIT TRANSACTION;

        PRINT 'Egresado insertado correctamente.';

    END TRY

    BEGIN CATCH

        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        INSERT INTO LogExcepciones
        (
            TablaAfectada,
            UUID,
            ReglaIncumplida,
            Descripcion
        )
        VALUES
        (
            'Egresados',
            @UUID,
            'Error durante inserción',
            ERROR_MESSAGE()
        );

        THROW;

    END CATCH
END;
GO
