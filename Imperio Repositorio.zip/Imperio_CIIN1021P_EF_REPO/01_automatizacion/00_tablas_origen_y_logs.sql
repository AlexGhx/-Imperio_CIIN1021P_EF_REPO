IF DB_ID('baseMINSA') IS NULL
    CREATE DATABASE baseMINSA;
GO

USE baseMINSA;
GO

IF OBJECT_ID('dbo.Egresados', 'U') IS NULL
CREATE TABLE dbo.Egresados (
    UUID                    VARCHAR(100) MASKED WITH (FUNCTION = 'partial(2, "********", 2)') NULL,
    HISTORIA                VARCHAR(100) MASKED WITH (FUNCTION = 'partial(1, "*****", 1)') NULL,
    SEXO                    VARCHAR(20)  NULL,
    EDAD                    INT          NULL,
    FECHA_INGRESO           DATE         NULL,
    FECHA_EGRESO            DATE         NULL,
    UBIGEO_LUGAR_RESIDENCIA VARCHAR(20)  NULL,
    LUGAR_RESIDENCIA        VARCHAR(200) NULL,
    FECHA_CORTE             DATE         NULL
);
GO

IF OBJECT_ID('dbo.PacientesNuevos', 'U') IS NULL
CREATE TABLE dbo.PacientesNuevos (
    UUID                    VARCHAR(100) MASKED WITH (FUNCTION = 'partial(2, "********", 2)') NULL,
    HISTORIA                VARCHAR(100) MASKED WITH (FUNCTION = 'partial(1, "*****", 1)') NULL,
    FEC_FILIACION           DATE         NULL,
    SEXO                    VARCHAR(20)  NULL,
    EDAD                    INT          NULL,
    UBIGEO_LUGAR_RESIDENCIA VARCHAR(20)  NULL,
    LUGAR_RESIDENCIA        VARCHAR(200) NULL,
    CANT_ATENCIONES_CEX     INT          NULL,
    FECHA_CORTE             DATE         NULL
);
GO

IF OBJECT_ID('dbo.LogAuditoria', 'U') IS NULL
CREATE TABLE dbo.LogAuditoria (
    LogID         INT IDENTITY(1,1) PRIMARY KEY,
    FechaHora     DATETIME      NOT NULL DEFAULT GETDATE(),
    Usuario       VARCHAR(128)  NULL,
    TablaAfectada VARCHAR(100)  NULL,
    Operacion     VARCHAR(20)   NULL,
    ValorAnterior NVARCHAR(MAX) NULL,
    ValorNuevo    NVARCHAR(MAX) NULL
);
GO

IF OBJECT_ID('dbo.LogExcepciones', 'U') IS NULL
CREATE TABLE dbo.LogExcepciones (
    LogID           INT IDENTITY(1,1) PRIMARY KEY,
    FechaHora       DATETIME      NOT NULL DEFAULT GETDATE(),
    TablaAfectada   VARCHAR(100)  NULL,
    UUID            VARCHAR(100)  NULL,
    ReglaIncumplida VARCHAR(200)  NULL,
    Descripcion     VARCHAR(500)  NULL
);
GO
