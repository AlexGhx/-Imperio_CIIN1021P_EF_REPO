USE baseMINSA;
GO

CREATE OR ALTER TRIGGER trg_AuditoriaEgresados
ON Egresados
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO LogAuditoria
    (
        Usuario,
        TablaAfectada,
        Operacion,
        ValorAnterior,
        ValorNuevo
    )
    SELECT
        SUSER_SNAME(),
        'Egresados',
        'INSERT',
        NULL,
        'UUID=' + CAST(i.UUID AS VARCHAR(100))
    FROM inserted i
    LEFT JOIN deleted d ON i.UUID = d.UUID
    WHERE d.UUID IS NULL;

    INSERT INTO LogAuditoria
    (
        Usuario,
        TablaAfectada,
        Operacion,
        ValorAnterior,
        ValorNuevo
    )
    SELECT
        SUSER_SNAME(),
        'Egresados',
        'UPDATE',
        'UUID=' + CAST(d.UUID AS VARCHAR(100))
            + ', EDAD=' + CAST(d.EDAD AS VARCHAR(10))
            + ', FECHA_INGRESO=' + CONVERT(VARCHAR(10), d.FECHA_INGRESO, 120)
            + ', FECHA_EGRESO=' + CONVERT(VARCHAR(10), d.FECHA_EGRESO, 120),
        'UUID=' + CAST(i.UUID AS VARCHAR(100))
            + ', EDAD=' + CAST(i.EDAD AS VARCHAR(10))
            + ', FECHA_INGRESO=' + CONVERT(VARCHAR(10), i.FECHA_INGRESO, 120)
            + ', FECHA_EGRESO=' + CONVERT(VARCHAR(10), i.FECHA_EGRESO, 120)
    FROM inserted i
    INNER JOIN deleted d ON i.UUID = d.UUID;

    INSERT INTO LogAuditoria
    (
        Usuario,
        TablaAfectada,
        Operacion,
        ValorAnterior,
        ValorNuevo
    )
    SELECT
        SUSER_SNAME(),
        'Egresados',
        'DELETE',
        'UUID=' + CAST(d.UUID AS VARCHAR(100)),
        NULL
    FROM deleted d
    LEFT JOIN inserted i ON d.UUID = i.UUID
    WHERE i.UUID IS NULL;
END;
GO
