USE baseMINSA;
GO

CREATE OR ALTER FUNCTION dbo.fn_DiasEstancia (@FechaIngreso DATE, @FechaEgreso DATE)
RETURNS INT
AS
BEGIN
    RETURN DATEDIFF(DAY, @FechaIngreso, @FechaEgreso);
END;
GO

SELECT dbo.fn_DiasEstancia('2026-09-01', '2026-09-05') AS DiasEstancia;
GO

SELECT TOP (10)
       FECHA_INGRESO,
       FECHA_EGRESO,
       dbo.fn_DiasEstancia(FECHA_INGRESO, FECHA_EGRESO) AS DiasEstancia
FROM dbo.Egresados;
GO
