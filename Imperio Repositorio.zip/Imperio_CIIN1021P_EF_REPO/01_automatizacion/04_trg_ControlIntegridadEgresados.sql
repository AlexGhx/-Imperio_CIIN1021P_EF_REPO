USE baseMINSA;
GO

CREATE OR ALTER TRIGGER trg_ControlIntegridadEgresados
ON Egresados
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO LogExcepciones
    (
        TablaAfectada,
        UUID,
        ReglaIncumplida,
        Descripcion
    )
    SELECT
        'Egresados',
        i.UUID,
        'Fecha de egreso inválida',
        'La fecha de egreso es anterior a la fecha de ingreso.'
    FROM inserted i
    WHERE i.FECHA_EGRESO < i.FECHA_INGRESO;

    DELETE E
    FROM Egresados E
    INNER JOIN inserted i
        ON E.UUID = i.UUID
       AND E.FECHA_INGRESO = i.FECHA_INGRESO
       AND E.FECHA_EGRESO = i.FECHA_EGRESO
    WHERE i.FECHA_EGRESO < i.FECHA_INGRESO;
END;
GO
