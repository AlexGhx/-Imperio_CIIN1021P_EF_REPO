USE baseMINSA;
GO

CREATE OR ALTER PROCEDURE sp_InsertarPacienteNuevo
    @UUID VARCHAR(100),
    @HISTORIA VARCHAR(100),
    @FEC_FILIACION DATE,
    @SEXO VARCHAR(20),
    @EDAD INT,
    @UBIGEO_LUGAR_RESIDENCIA VARCHAR(20),
    @LUGAR_RESIDENCIA VARCHAR(200),
    @CANT_ATENCIONES_CEX INT,
    @FECHA_CORTE DATE
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        BEGIN TRANSACTION;

        SAVE TRANSACTION PuntoSeguro;

        IF EXISTS (
            SELECT 1
            FROM PacientesNuevos
            WHERE UUID = @UUID
        )
        BEGIN
            INSERT INTO LogExcepciones
            (
                TablaAfectada,
                UUID,
                ReglaIncumplida,
                Descripcion
            )
            VALUES
            (
                'PacientesNuevos',
                @UUID,
                'UUID duplicado',
                'El paciente ya existe en la tabla.'
            );

            ROLLBACK TRANSACTION PuntoSeguro;

            COMMIT TRANSACTION;
            RETURN;
        END;

        INSERT INTO PacientesNuevos
        (
            UUID,
            HISTORIA,
            FEC_FILIACION,
            SEXO,
            EDAD,
            UBIGEO_LUGAR_RESIDENCIA,
            LUGAR_RESIDENCIA,
            CANT_ATENCIONES_CEX,
            FECHA_CORTE
        )
        VALUES
        (
            @UUID,
            @HISTORIA,
            @FEC_FILIACION,
            @SEXO,
            @EDAD,
            @UBIGEO_LUGAR_RESIDENCIA,
            @LUGAR_RESIDENCIA,
            @CANT_ATENCIONES_CEX,
            @FECHA_CORTE
        );

        COMMIT TRANSACTION;

        PRINT 'Paciente insertado correctamente.';
    END TRY

    BEGIN CATCH

        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        INSERT INTO LogExcepciones
        (
            TablaAfectada,
            UUID,
            ReglaIncumplida,
            Descripcion
        )
        VALUES
        (
            'PacientesNuevos',
            @UUID,
            'Error durante inserción',
            ERROR_MESSAGE()
        );

        THROW;
    END CATCH
END;
GO
