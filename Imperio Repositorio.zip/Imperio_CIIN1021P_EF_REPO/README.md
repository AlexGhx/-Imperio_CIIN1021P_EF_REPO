# DataSalud Perú · Sistema integrado de base de datos segura, automatizada e inteligente (DIRESA La Libertad)

Proyecto integrador del curso **Base de Datos Avanzadas y Big Data (CIIN1021P)** · UPN · Grupo **Imperio**
Datos de trabajo: conjuntos abiertos del MINSA (datosabiertos.gob.pe), egresos hospitalarios y pacientes nuevos, enero 2022 a julio 2026, descargados el 05/09/2026.

- Egresos hospitalarios: <https://www.datosabiertos.gob.pe/dataset/listado-de-egresos-hospitalarios-enero-2022-julio-2026-%E2%80%93-instituto-nacional-de-enfermedades>
- Pacientes nuevos: <https://www.datosabiertos.gob.pe/dataset/listado-de-pacientes-nuevos-enero-2022-julio-2026-instituto-nacional-de-enfermedades>

## Estructura del repositorio

```
.
├── 01_automatizacion/                  Bloque Automatización (Cap. 2)
│   ├── 00_tablas_origen_y_logs.sql         Egresados, PacientesNuevos, LogAuditoria, LogExcepciones
│   ├── 01_sp_InsertarPacienteNuevo.sql     Procedimiento: valida UUID duplicado
│   ├── 02_sp_InsertarEgresado.sql          Procedimiento: valida fechas, edad y episodio duplicado
│   ├── 03_trg_AuditoriaEgresados.sql       Trigger de auditoría (INSERT/UPDATE/DELETE)
│   ├── 04_trg_ControlIntegridadEgresados.sql  Trigger de integridad de fechas
│   └── 05_fn_DiasEstancia.sql              Función de días de estancia
├── 02_seguridad/                       Bloque Seguridad (Cap. 3)
│   ├── 01_roles_y_privilegios.sql          3 roles con GRANT/DENY y UNMASK solo para el administrador
│   ├── 02_respaldo_y_restauracion.sql      FULL + DIFFERENTIAL, VERIFYONLY y prueba de restauración
│   ├── 03_indice_y_plan_ejecucion.sql      Consulta crítica, índice de cobertura y medición antes/después
│   └── 04_enmascarado_dw.sql               Máscara de UUID/HISTORIA en el esquema dw (opcional)
├── 03_BI/                              Bloque Inteligencia de negocios (Caps. 5 y 6)
│   ├── 01_dw_ddl_modelo_dimensional.sql    DDL Kimball: 4 dimensiones y 2 tablas de hechos
│   ├── 02_etl_datawarehouse.py             ETL Python/pandas con registro de ejecución
│   └── Base_Datos.pbix                     Dashboard Power BI (KPIs y análisis OLAP)
├── 04_BigData/                         Bloque Big Data y NoSQL (Caps. 4 y 7)
│   ├── DataSalud_Spark.ipynb               PySpark: limpieza, consulta crítica, tiempos y escalabilidad
│   ├── evidencias/escalabilidad_spark.png  Gráfica de la prueba de escalabilidad
│   ├── cargar_mongo.py                     SQL Server a MongoDB: un documento por paciente (egresos)
│   ├── cargar_mongo_nuevos.py              SQL Server a MongoDB: un documento por fila (pacientes nuevos)
│   └── mongodb_crud.js                     CRUD sobre pacientes_egresados
└── docs/
    └── matriz_trazabilidad.md              Rúbrica, pasos de práctica y secciones del informe
```

| Informe | Carpeta | Requisitos que cubre |
|---|---|---|
| Cap. 2 Automatización | `01_automatizacion/` | RF01 a RF05 |
| Cap. 3 Seguridad | `02_seguridad/` | RF07 a RF10 (Ley N.° 29733, artículos 9 y 16) |
| Cap. 4 SQL y NoSQL | `04_BigData/` (`cargar_mongo*.py`, `mongodb_crud.js`) | RF03, RF14 |
| Cap. 5 Data Warehouse y ETL | `03_BI/` (`01_` y `02_`) | RF11, RF12 |
| Cap. 6 Dashboard y OLAP | `03_BI/Base_Datos.pbix` | RF13 a RF18 |
| Cap. 7 Spark | `04_BigData/DataSalud_Spark.ipynb` | RF13, RF16 |

## Herramientas requeridas (todas gratuitas)

| Herramienta | Uso | Notas |
|---|---|---|
| SQL Server Express y SQL Server Management Studio (SSMS) | Base `baseMINSA`, scripts `.sql` | Instancia usada: `.\SQLEXPRESS` |
| Python 3.10 o superior | ETL y cargadores de MongoDB | El ETL se ejecutó con Python 3.14 |
| `pandas`, `sqlalchemy`, `pyodbc`, `pymongo` | Librerías de Python | `pip install pandas sqlalchemy pyodbc pymongo` |
| ODBC Driver 17 for SQL Server | Conexión de Python a SQL Server | Instalador de Microsoft |
| Power BI Desktop | Abrir `Base_Datos.pbix` | |
| MongoDB Community (y Compass o `mongosh`) | Colecciones y CRUD | `pymongo` solo se necesita para los cargadores |
| Google Colab (capa gratuita) | Cuaderno PySpark | `pyspark` se instala en la primera celda (Spark 4.0.4 en la ejecución del informe) |

## Instrucciones de ejecución (en este orden)

Cada paso indica cómo comprobar que salió bien.

1. **Base de datos y tablas de origen.** En SSMS, ejecutar `01_automatizacion/00_tablas_origen_y_logs.sql` (crea `baseMINSA`, `Egresados`, `PacientesNuevos`, `LogAuditoria` y `LogExcepciones`) e importar los dos CSV de datosabiertos.gob.pe con *Tareas > Importar archivo plano*.
   *Comprobación:* `SELECT COUNT(*)` da 54,640 en `Egresados` y 78,976 en `PacientesNuevos`.
2. **Automatización.** Ejecutar `01_` a `05_` de `01_automatizacion/` en orden numérico. Probar la función con `SELECT dbo.fn_DiasEstancia('2026-09-01','2026-09-05');`.
   *Comprobación:* devuelve 4. Los casos inválidos quedan en `LogExcepciones` y las operaciones en `LogAuditoria`.
3. **Seguridad.** Ejecutar `02_seguridad/01_roles_y_privilegios.sql` y asignar los usuarios (sección 3 del script, con contraseñas propias). Luego `03_indice_y_plan_ejecucion.sql` (anotar lecturas y tiempos antes y después) y `02_respaldo_y_restauracion.sql` (crear antes la carpeta `C:\Backups`; ajustar fechas y rutas de la prueba de restauración).
   *Comprobación:* con `usr_analista_01`, `UUID` e `HISTORIA` salen enmascarados; el conteo de la base restaurada coincide con el original.
4. **Data Warehouse y ETL.** Ejecutar `03_BI/01_dw_ddl_modelo_dimensional.sql` una sola vez. Luego, con un login que tenga permiso `UNMASK`, correr `python 03_BI/02_etl_datawarehouse.py`. La conexión por defecto usa autenticación de Windows contra `AnghVC\SQLEXPRESS`; para otro servidor, definir la variable de entorno `DATASALUD_CONN_STR` (formato SQLAlchemy). Si se dispone del catálogo de ubigeos del INEI, guardarlo como `catalogo_ubigeo_inei.csv` junto al script (columnas `ubigeo,provincia,distrito`) para completar Provincia y Distrito.
   *Comprobación:* ver la tabla de resultados de referencia; el registro queda en consola y en `etl_datasalud.log`. El ETL recarga los hechos completos, así que puede repetirse sin duplicar filas.
5. **Enmascarado en el DW (opcional).** `02_seguridad/04_enmascarado_dw.sql` aplica la misma máscara a `UUID`, `HISTORIA` y `UUID_Origen` en el esquema `dw`.
6. **Dashboard.** Abrir `03_BI/Base_Datos.pbix` en Power BI Desktop, cambiar el origen de datos al servidor propio (*Transformar datos > Configuración del origen de datos*) y pulsar **Actualizar**.
7. **NoSQL.** Con MongoDB en `localhost:27017`: `python 04_BigData/cargar_mongo.py`, `python 04_BigData/cargar_mongo_nuevos.py` y `mongosh --file 04_BigData/mongodb_crud.js`.
   *Comprobación:* 34,480 pacientes, 54,603 ingresos y 11,593 pacientes con reingreso en `pacientes_egresados`; 78,976 documentos en `pacientes_nuevos`.
8. **Big Data.** Exportar `Egresados` a CSV con un usuario que tenga `UNMASK` (o usar el CSV original del MINSA), subir `04_BigData/DataSalud_Spark.ipynb` a Google Colab y ejecutar las celdas en orden; subir el CSV cuando la celda 2 lo pida. Medir la misma consulta en SQL Server (bloque ANTES/DESPUÉS de `02_seguridad/03_indice_y_plan_ejecucion.sql`, 5 corridas) y escribir el promedio en la variable `tiempo_promedio_sql_server` de la celda de comparación.

## Resultados de referencia

| Elemento | Valor esperado |
|---|---|
| Egresos de origen / duplicados exactos / sin UUID / episodios cargados | 54,640 / 36 / 1 / **54,603** |
| Pacientes con reingreso | 11,593 |
| `dw.DimGrupoEtario` / `dw.DimTiempo` | 4 / 1,826 |
| `dw.DimPaciente` / `dw.DimUbicacion` | 113,454 / 1,806 |
| `dw.Hechos_Episodios_Hospitalizacion` | 54,603 |
| `dw.Hechos_AtencionesCEX` | 78,976 |
| Estancia promedio (Power BI y Spark) | 7.95 días |

## Seguridad y datos

- No se suben al repositorio respaldos (`.bak`), archivos de datos ni CSV de origen, ni credenciales; ver `.gitignore`. Las contraseñas de los inicios de sesión no están en el código.
- Los identificadores `UUID` y `HISTORIA` del MINSA ya vienen seudonimizados; aun así, en SQL Server solo `rol_administrador_bd` los ve sin enmascarar.
- `Base_Datos.pbix` está en modo Importar: guarda una copia de las tablas del Data Warehouse. Sus visuales usan solo atributos agregados o no identificables (sexo, grupo etario, departamento, año). Para que un usuario analista no importe identificadores en claro, aplicar el paso 5.
- El cuaderno de Spark conserva las salidas de la ejecución, que incluyen cinco filas de ejemplo con identificadores seudonimizados.
- Marco normativo: Ley N.° 29733 y su reglamento (D.S. N.° 003-2013-JUS), y controles de ISO 27001.

## Trazabilidad

Ver `docs/matriz_trazabilidad.md`.
