USE baseMINSA;
GO

ALTER TABLE dw.DimPaciente ALTER COLUMN UUID     ADD MASKED WITH (FUNCTION = 'partial(2, "********", 2)');
ALTER TABLE dw.DimPaciente ALTER COLUMN HISTORIA ADD MASKED WITH (FUNCTION = 'partial(1, "*****", 1)');
ALTER TABLE dw.Hechos_Episodios_Hospitalizacion ALTER COLUMN UUID_Origen ADD MASKED WITH (FUNCTION = 'partial(2, "********", 2)');
ALTER TABLE dw.Hechos_AtencionesCEX             ALTER COLUMN UUID_Origen ADD MASKED WITH (FUNCTION = 'partial(2, "********", 2)');
GO
