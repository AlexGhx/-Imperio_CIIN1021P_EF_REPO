USE master;
GO

ALTER DATABASE baseMINSA SET RECOVERY FULL;
GO

DECLARE @Carpeta NVARCHAR(200) = N'C:\Backups\';
DECLARE @Archivo NVARCHAR(260) = @Carpeta + N'baseMINSA_FULL_' + FORMAT(GETDATE(), 'yyyyMMdd') + N'.bak';

BACKUP DATABASE baseMINSA
TO DISK = @Archivo
WITH INIT, CHECKSUM, STATS = 10, NAME = N'baseMINSA-Full';

RESTORE VERIFYONLY FROM DISK = @Archivo WITH CHECKSUM;
GO

DECLARE @Carpeta NVARCHAR(200) = N'C:\Backups\';
DECLARE @Archivo NVARCHAR(260) = @Carpeta + N'baseMINSA_DIFF_' + FORMAT(GETDATE(), 'yyyyMMdd') + N'.bak';

BACKUP DATABASE baseMINSA
TO DISK = @Archivo
WITH DIFFERENTIAL, INIT, CHECKSUM, STATS = 10, NAME = N'baseMINSA-Diferencial';

RESTORE VERIFYONLY FROM DISK = @Archivo WITH CHECKSUM;
GO

RESTORE FILELISTONLY FROM DISK = N'C:\Backups\baseMINSA_FULL_20261004.bak';
GO

RESTORE DATABASE DataSalud_Restaurada
FROM DISK = N'C:\Backups\baseMINSA_FULL_20261004.bak'
WITH MOVE 'base_datos'     TO N'C:\Program Files\Microsoft SQL Server\MSSQL17.SQLEXPRESS\MSSQL\DATA\DataSalud_Restaurada.mdf',
     MOVE 'base_datos_log' TO N'C:\Program Files\Microsoft SQL Server\MSSQL17.SQLEXPRESS\MSSQL\DATA\DataSalud_Restaurada_log.ldf',
     NORECOVERY, REPLACE, STATS = 10;
GO

RESTORE DATABASE DataSalud_Restaurada
FROM DISK = N'C:\Backups\baseMINSA_DIFF_20261008.bak'
WITH RECOVERY, STATS = 10;
GO

USE DataSalud_Restaurada;
GO
ALTER USER usr_admin_bd    WITH LOGIN = login_admin_bd;
ALTER USER usr_analista_01 WITH LOGIN = login_analista_01;
ALTER USER usr_auditor_01  WITH LOGIN = login_auditor_01;
GO

SELECT 'Original'   AS Origen, COUNT(*) AS TotalEgresados FROM baseMINSA.dbo.Egresados
UNION ALL
SELECT 'Restaurada', COUNT(*) FROM DataSalud_Restaurada.dbo.Egresados;

SELECT 'Original'   AS Origen, COUNT(*) AS TotalPacientesNuevos FROM baseMINSA.dbo.PacientesNuevos
UNION ALL
SELECT 'Restaurada', COUNT(*) FROM DataSalud_Restaurada.dbo.PacientesNuevos;
GO
