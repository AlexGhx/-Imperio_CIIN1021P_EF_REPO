USE baseMINSA;
GO

IF SCHEMA_ID('dw') IS NULL EXEC('CREATE SCHEMA dw');
GO

IF DATABASE_PRINCIPAL_ID('rol_administrador_bd') IS NULL CREATE ROLE rol_administrador_bd;
IF DATABASE_PRINCIPAL_ID('rol_analista_datos')   IS NULL CREATE ROLE rol_analista_datos;
IF DATABASE_PRINCIPAL_ID('rol_auditor')          IS NULL CREATE ROLE rol_auditor;
GO

GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.Egresados       TO rol_administrador_bd;
GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.PacientesNuevos TO rol_administrador_bd;
GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dw          TO rol_administrador_bd;
GRANT EXECUTE ON dbo.sp_InsertarPacienteNuevo TO rol_administrador_bd;
GRANT EXECUTE ON dbo.sp_InsertarEgresado      TO rol_administrador_bd;
GRANT SELECT  ON dbo.LogAuditoria   TO rol_administrador_bd;
GRANT SELECT  ON dbo.LogExcepciones TO rol_administrador_bd;
DENY INSERT, UPDATE, DELETE ON dbo.LogAuditoria   TO rol_administrador_bd;
DENY INSERT, UPDATE, DELETE ON dbo.LogExcepciones TO rol_administrador_bd;
GRANT UNMASK TO rol_administrador_bd;
GO

GRANT SELECT ON dbo.Egresados       TO rol_analista_datos;
GRANT SELECT ON dbo.PacientesNuevos TO rol_analista_datos;
GRANT SELECT ON SCHEMA::dw          TO rol_analista_datos;
DENY  SELECT ON dbo.LogAuditoria    TO rol_analista_datos;
DENY  SELECT ON dbo.LogExcepciones  TO rol_analista_datos;
DENY  INSERT, UPDATE, DELETE ON dbo.LogAuditoria   TO rol_analista_datos;
DENY  INSERT, UPDATE, DELETE ON dbo.LogExcepciones TO rol_analista_datos;
GO

GRANT SELECT ON dbo.LogAuditoria   TO rol_auditor;
GRANT SELECT ON dbo.LogExcepciones TO rol_auditor;
DENY  INSERT, UPDATE, DELETE ON dbo.LogAuditoria   TO rol_auditor;
DENY  INSERT, UPDATE, DELETE ON dbo.LogExcepciones TO rol_auditor;
DENY  SELECT ON dbo.Egresados       TO rol_auditor;
DENY  SELECT ON dbo.PacientesNuevos TO rol_auditor;
DENY  SELECT ON SCHEMA::dw          TO rol_auditor;
GO
