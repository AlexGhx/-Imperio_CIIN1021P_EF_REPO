USE [baseMINSA]
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'dw')
   EXEC('CREATE SCHEMA dw');
GO
CREATE TABLE dw.DimPaciente (
   SK_Paciente     INT IDENTITY(1,1) PRIMARY KEY,
    UUID            VARCHAR(100) NOT NULL,
    HISTORIA        VARCHAR(100) NULL,
    SEXO            VARCHAR(20)  NULL,   CONSTRAINT UQ_DimPaciente_UUID UNIQUE (UUID)
);
GO
CREATE TABLE dw.DimTiempo (
   SK_Tiempo       INT PRIMARY KEY,        
    Fecha           DATE NOT NULL,
    Anio            INT NOT NULL,
    Mes             INT NOT NULL,
    NombreMes       VARCHAR(20) NOT NULL,
    Trimestre       INT NOT NULL,
    DiaSemana       VARCHAR(20) NOT NULL,
    EsFinDeSemana   BIT NOT NULL
);
GO
CREATE TABLE dw.DimUbicacion (
    SK_Ubicacion        INT IDENTITY(1,1) PRIMARY KEY,
    Ubigeo              VARCHAR(20) NOT NULL,
    Departamento        VARCHAR(50) NULL,
    Provincia           VARCHAR(50) NULL,
    Distrito            VARCHAR(50) NULL,
    LugarResidenciaTexto VARCHAR(200) NULL,
    CONSTRAINT UQ_DimUbicacion_Ubigeo UNIQUE (Ubigeo)
);
GO
CREATE TABLE dw.DimGrupoEtario (
    SK_GrupoEtario  INT IDENTITY(1,1) PRIMARY KEY,
    EdadMin         INT NOT NULL,
    EdadMax         INT NOT NULL,
    Etiqueta        VARCHAR(20) NOT NULL,
    CONSTRAINT UQ_DimGrupoEtario_Etiqueta UNIQUE (Etiqueta)
);
GO

IF NOT EXISTS (SELECT 1 FROM dw.DimGrupoEtario)
INSERT INTO dw.DimGrupoEtario (EdadMin, EdadMax, Etiqueta) VALUES
    (0,   17,  '0-17'),
    (18,  29,  '18-29'),
    (30,  59,  '30-59'),
    (60,  110, '60+');
GO
CREATE TABLE dw.Hechos_Episodios_Hospitalizacion (
    SK_Episodio         INT IDENTITY(1,1) PRIMARY KEY,
    SK_Paciente         INT NOT NULL REFERENCES dw.DimPaciente(SK_Paciente),
    SK_Tiempo_Ingreso   INT NOT NULL REFERENCES dw.DimTiempo(SK_Tiempo),
    SK_Tiempo_Egreso    INT NULL     REFERENCES dw.DimTiempo(SK_Tiempo),
    SK_Ubicacion        INT NOT NULL REFERENCES dw.DimUbicacion(SK_Ubicacion),
    SK_GrupoEtario      INT NOT NULL REFERENCES dw.DimGrupoEtario(SK_GrupoEtario),
    UUID_Origen         VARCHAR(100) NOT NULL,
    FechaCorte_Origen   DATE NULL,
    Dias_Estancia       INT NULL,    
    Es_Reingreso        BIT NOT NULL DEFAULT 0,
    Numero_Episodio     INT NOT NULL DEFAULT 1,
    Edad_Al_Ingreso     INT NULL
);
GO
CREATE INDEX IX_Hechos_Episodios_Paciente   ON dw.Hechos_Episodios_Hospitalizacion(SK_Paciente);
CREATE INDEX IX_Hechos_Episodios_Ubicacion  ON dw.Hechos_Episodios_Hospitalizacion(SK_Ubicacion);
CREATE INDEX IX_Hechos_Episodios_Tiempo     ON dw.Hechos_Episodios_Hospitalizacion(SK_Tiempo_Ingreso);
GO
CREATE TABLE dw.Hechos_AtencionesCEX (
    SK_AtencionCEX      INT IDENTITY(1,1) PRIMARY KEY,
    SK_Paciente         INT NOT NULL REFERENCES dw.DimPaciente(SK_Paciente),
    SK_Tiempo_Filiacion INT NOT NULL REFERENCES dw.DimTiempo(SK_Tiempo),
    SK_Ubicacion        INT NOT NULL REFERENCES dw.DimUbicacion(SK_Ubicacion),
    SK_GrupoEtario      INT NOT NULL REFERENCES dw.DimGrupoEtario(SK_GrupoEtario),

    UUID_Origen         VARCHAR(100) NOT NULL,
    Cant_Atenciones_CEX INT NULL
);
GO
IF NOT EXISTS (SELECT 1 FROM dw.DimTiempo)
BEGIN
DECLARE @FechaInicio DATE = '2022-01-01';
DECLARE @FechaFin    DATE = '2026-12-31';

;WITH Fechas AS (
    SELECT @FechaInicio AS Fecha
    UNION ALL
    SELECT DATEADD(DAY, 1, Fecha) FROM Fechas WHERE Fecha < @FechaFin
)
INSERT INTO dw.DimTiempo (SK_Tiempo, Fecha, Anio, Mes, NombreMes, Trimestre, DiaSemana, EsFinDeSemana)
SELECT
    CONVERT(INT, FORMAT(Fecha, 'yyyyMMdd'))        AS SK_Tiempo,
    Fecha,
    YEAR(Fecha)                                     AS Anio,
    MONTH(Fecha)                                    AS Mes,
    DATENAME(MONTH, Fecha)                          AS NombreMes,
    DATEPART(QUARTER, Fecha)                        AS Trimestre,
    DATENAME(WEEKDAY, Fecha)                        AS DiaSemana,
    CASE WHEN DATENAME(WEEKDAY, Fecha) IN ('Saturday','Sunday') THEN 1 ELSE 0 END AS EsFinDeSemana
FROM Fechas
OPTION (MAXRECURSION 0);
END
GO
