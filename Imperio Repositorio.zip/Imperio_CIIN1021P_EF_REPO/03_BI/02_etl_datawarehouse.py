"""
DataSalud Perú - DIRESA La Libertad
Proceso ETL: Egresados / PacientesNuevos (baseMINSA) -> Data Warehouse (esquema dw)

Extract  -> lee de las tablas operacionales en SQL Server
Transform -> limpieza, deduplicación, cálculo de dimensiones y métricas
Load     -> inserta en dw.DimPaciente, dw.DimUbicacion y recarga las dos tablas de hechos
            (dw.Hechos_Episodios_Hospitalizacion y dw.Hechos_AtencionesCEX)

Requisitos:
    pip install pandas sqlalchemy pyodbc

El login usado en la cadena de conexión debe tener permiso UNMASK sobre
Egresados/PacientesNuevos (mismo privilegio que rol_administrador_bd),
porque UUID e HISTORIA tienen Dynamic Data Masking en el origen.
Las tablas de hechos se recargan completas en cada ejecución; las dimensiones solo insertan lo que falta.
"""

import logging
import os
from datetime import datetime

import pandas as pd
from sqlalchemy import create_engine, text

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler("etl_datasalud.log"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("ETL_DataSalud")

CONN_STR = os.environ.get(
    "DATASALUD_CONN_STR",
    "mssql+pyodbc://@AnghVC\\SQLEXPRESS/baseMINSA"
    "?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes",
)
engine = create_engine(CONN_STR)

DEPARTAMENTOS_INEI = {
    "01": "Amazonas", "02": "Áncash", "03": "Apurímac", "04": "Arequipa",
    "05": "Ayacucho", "06": "Cajamarca", "07": "Callao", "08": "Cusco",
    "09": "Huancavelica", "10": "Huánuco", "11": "Ica", "12": "Junín",
    "13": "La Libertad", "14": "Lambayeque", "15": "Lima", "16": "Loreto",
    "17": "Madre de Dios", "18": "Moquegua", "19": "Pasco", "20": "Piura",
    "21": "Puno", "22": "San Martín", "23": "Tacna", "24": "Tumbes",
    "25": "Ucayali",
}

RUTA_CATALOGO_UBIGEO = "catalogo_ubigeo_inei.csv"


def grupo_etario(edad: int) -> str:
    if pd.isna(edad):
        return None
    if edad <= 17:
        return "0-17"
    if edad <= 29:
        return "18-29"
    if edad <= 59:
        return "30-59"
    return "60+"


def extraer() -> tuple[pd.DataFrame, pd.DataFrame]:
    log.info("Extrayendo datos de Egresados y PacientesNuevos...")
    df_egresados = pd.read_sql("SELECT * FROM dbo.Egresados", engine)
    df_nuevos = pd.read_sql("SELECT * FROM dbo.PacientesNuevos", engine)
    log.info(f"Egresados: {len(df_egresados)} filas | PacientesNuevos: {len(df_nuevos)} filas")
    return df_egresados, df_nuevos


def transformar(df_egresados: pd.DataFrame, df_nuevos: pd.DataFrame):
    filas_iniciales = len(df_egresados)

    df_egresados["FECHA_INGRESO"] = pd.to_datetime(df_egresados["FECHA_INGRESO"])
    df_egresados["FECHA_EGRESO"] = pd.to_datetime(df_egresados["FECHA_EGRESO"])

    df_egresados = df_egresados.drop_duplicates(
        subset=["UUID", "FECHA_INGRESO", "FECHA_EGRESO"]
    )
    duplicados_removidos = filas_iniciales - len(df_egresados)
    log.info(f"Duplicados exactos removidos: {duplicados_removidos}")

    sin_uuid = df_egresados["UUID"].isna().sum()
    if sin_uuid > 0:
        log.warning(
            f"{sin_uuid} episodios sin UUID (NULL) encontrados en Egresados -> "
            "excluidos del DW. Revisar el origen de estos registros en SQL Server "
            "(SELECT * FROM dbo.Egresados WHERE UUID IS NULL)."
        )
        df_egresados = df_egresados[df_egresados["UUID"].notna()]

    invalidos = df_egresados[df_egresados["FECHA_EGRESO"] < df_egresados["FECHA_INGRESO"]]
    if len(invalidos) > 0:
        log.warning(f"{len(invalidos)} episodios con FECHA_EGRESO anterior a FECHA_INGRESO -> excluidos del DW")
        df_egresados = df_egresados[df_egresados["FECHA_EGRESO"] >= df_egresados["FECHA_INGRESO"]]

    df_egresados["Dias_Estancia"] = (
        df_egresados["FECHA_EGRESO"] - df_egresados["FECHA_INGRESO"]
    ).dt.days

    df_egresados = df_egresados.sort_values(["UUID", "FECHA_INGRESO"])
    df_egresados["Numero_Episodio"] = df_egresados.groupby("UUID").cumcount() + 1
    df_egresados["Es_Reingreso"] = df_egresados.groupby("UUID")["UUID"].transform("count") > 1

    df_egresados["GrupoEtario"] = df_egresados["EDAD"].apply(grupo_etario)

    df_egresados["Departamento"] = (
        df_egresados["UBIGEO_LUGAR_RESIDENCIA"].astype(str).str[:2].map(DEPARTAMENTOS_INEI)
    )

    try:
        catalogo = pd.read_csv(RUTA_CATALOGO_UBIGEO, dtype=str)
        df_egresados = df_egresados.merge(
            catalogo, left_on="UBIGEO_LUGAR_RESIDENCIA", right_on="ubigeo", how="left"
        )
        log.info("Catálogo de ubigeos INEI cargado: provincia/distrito completados.")
    except FileNotFoundError:
        df_egresados["provincia"] = None
        df_egresados["distrito"] = None
        log.warning(
            f"No se encontró {RUTA_CATALOGO_UBIGEO}: Provincia/Distrito quedarán NULL. "
            "Descargar catálogo de ubigeos de INEI para completar esta dimensión."
        )

    reingresos = df_egresados["Es_Reingreso"].sum()
    log.info(f"Episodios finales: {len(df_egresados)} | Pacientes con reingreso: {df_egresados[df_egresados['Es_Reingreso']]['UUID'].nunique()}")

    return df_egresados


def limpiar_hechos():
    """
    Este ETL recarga el hecho completo en cada ejecución (no es incremental).
    Por eso, antes de insertar, se limpia lo que había, para que correr el
    script dos veces no duplique filas en las tablas de hechos.
    Las dimensiones NO se tocan aquí: esas sí son incrementales (solo
    insertan lo que falte).
    """
    with engine.begin() as conn:
        conn.execute(text("DELETE FROM dw.Hechos_Episodios_Hospitalizacion"))
        conn.execute(text("DELETE FROM dw.Hechos_AtencionesCEX"))
    log.info("Tablas de hechos limpiadas antes de la recarga (proceso full reload).")


def cargar(df: pd.DataFrame):
    log.info("Cargando dimensiones...")

    pacientes = df[["UUID", "HISTORIA", "SEXO"]].drop_duplicates(subset=["UUID"])
    existentes = pd.read_sql("SELECT UUID FROM dw.DimPaciente", engine)
    nuevos_pacientes = pacientes[~pacientes["UUID"].isin(existentes["UUID"])]
    if len(nuevos_pacientes) > 0:
        nuevos_pacientes.to_sql("DimPaciente", engine, schema="dw", if_exists="append", index=False)
    log.info(f"DimPaciente: {len(nuevos_pacientes)} pacientes nuevos insertados.")

    ubicaciones = df[["UBIGEO_LUGAR_RESIDENCIA", "Departamento", "LUGAR_RESIDENCIA"]].drop_duplicates(
        subset=["UBIGEO_LUGAR_RESIDENCIA"]
    ).rename(columns={
        "UBIGEO_LUGAR_RESIDENCIA": "Ubigeo",
        "LUGAR_RESIDENCIA": "LugarResidenciaTexto",
    })
    existentes_ubi = pd.read_sql("SELECT Ubigeo FROM dw.DimUbicacion", engine)
    nuevas_ubicaciones = ubicaciones[~ubicaciones["Ubigeo"].isin(existentes_ubi["Ubigeo"])]
    if len(nuevas_ubicaciones) > 0:
        nuevas_ubicaciones.to_sql("DimUbicacion", engine, schema="dw", if_exists="append", index=False)
    log.info(f"DimUbicacion: {len(nuevas_ubicaciones)} ubicaciones nuevas insertadas.")

    dim_paciente = pd.read_sql("SELECT SK_Paciente, UUID FROM dw.DimPaciente", engine)
    dim_ubicacion = pd.read_sql("SELECT SK_Ubicacion, Ubigeo FROM dw.DimUbicacion", engine)
    dim_grupo = pd.read_sql("SELECT SK_GrupoEtario, Etiqueta FROM dw.DimGrupoEtario", engine)

    hechos = (
        df.merge(dim_paciente, on="UUID", how="left")
          .merge(dim_ubicacion, left_on="UBIGEO_LUGAR_RESIDENCIA", right_on="Ubigeo", how="left")
          .merge(dim_grupo, left_on="GrupoEtario", right_on="Etiqueta", how="left")
    )

    hechos["SK_Tiempo_Ingreso"] = hechos["FECHA_INGRESO"].dt.strftime("%Y%m%d").astype(int)
    hechos["SK_Tiempo_Egreso"] = hechos["FECHA_EGRESO"].dt.strftime("%Y%m%d").astype(int)

    tabla_hechos = hechos[[
        "SK_Paciente", "SK_Tiempo_Ingreso", "SK_Tiempo_Egreso", "SK_Ubicacion",
        "SK_GrupoEtario", "UUID", "FECHA_CORTE", "Dias_Estancia", "Es_Reingreso",
        "Numero_Episodio", "EDAD",
    ]].rename(columns={
        "UUID": "UUID_Origen",
        "FECHA_CORTE": "FechaCorte_Origen",
        "EDAD": "Edad_Al_Ingreso",
    })

    filas_sin_sk = tabla_hechos[tabla_hechos[["SK_Paciente", "SK_Ubicacion", "SK_GrupoEtario"]].isna().any(axis=1)]
    if len(filas_sin_sk) > 0:
        log.warning(f"{len(filas_sin_sk)} episodios sin surrogate key completo -> excluidos de la carga de hechos.")
        tabla_hechos = tabla_hechos.dropna(subset=["SK_Paciente", "SK_Ubicacion", "SK_GrupoEtario"])

    tabla_hechos.to_sql(
        "Hechos_Episodios_Hospitalizacion", engine, schema="dw",
        if_exists="append", index=False,
    )
    log.info(f"Hechos_Episodios_Hospitalizacion: {len(tabla_hechos)} filas cargadas.")


def cargar_atenciones_cex(df_nuevos: pd.DataFrame):
    """Carga Hechos_AtencionesCEX a partir de PacientesNuevos."""
    df = df_nuevos.copy()
    df["FEC_FILIACION"] = pd.to_datetime(df["FEC_FILIACION"])
    df = df[df["UUID"].notna()]

    df["GrupoEtario"] = df["EDAD"].apply(grupo_etario)
    df["Departamento"] = (
        df["UBIGEO_LUGAR_RESIDENCIA"].astype(str).str[:2].map(DEPARTAMENTOS_INEI)
    )

    dim_paciente = pd.read_sql("SELECT SK_Paciente, UUID FROM dw.DimPaciente", engine)
    dim_ubicacion = pd.read_sql("SELECT SK_Ubicacion, Ubigeo FROM dw.DimUbicacion", engine)
    dim_grupo = pd.read_sql("SELECT SK_GrupoEtario, Etiqueta FROM dw.DimGrupoEtario", engine)

    pacientes_nuevos = df[["UUID", "HISTORIA", "SEXO"]].drop_duplicates(subset=["UUID"])
    faltantes_p = pacientes_nuevos[~pacientes_nuevos["UUID"].isin(dim_paciente["UUID"])]
    if len(faltantes_p) > 0:
        faltantes_p.to_sql("DimPaciente", engine, schema="dw", if_exists="append", index=False)
        dim_paciente = pd.read_sql("SELECT SK_Paciente, UUID FROM dw.DimPaciente", engine)
        log.info(f"DimPaciente: {len(faltantes_p)} pacientes adicionales insertados desde PacientesNuevos.")

    ubicaciones_nuevas = df[["UBIGEO_LUGAR_RESIDENCIA", "Departamento", "LUGAR_RESIDENCIA"]].drop_duplicates(
        subset=["UBIGEO_LUGAR_RESIDENCIA"]
    ).rename(columns={"UBIGEO_LUGAR_RESIDENCIA": "Ubigeo", "LUGAR_RESIDENCIA": "LugarResidenciaTexto"})
    faltantes_u = ubicaciones_nuevas[~ubicaciones_nuevas["Ubigeo"].isin(dim_ubicacion["Ubigeo"])]
    if len(faltantes_u) > 0:
        faltantes_u.to_sql("DimUbicacion", engine, schema="dw", if_exists="append", index=False)
        dim_ubicacion = pd.read_sql("SELECT SK_Ubicacion, Ubigeo FROM dw.DimUbicacion", engine)
        log.info(f"DimUbicacion: {len(faltantes_u)} ubicaciones adicionales insertadas desde PacientesNuevos.")

    hechos = (
        df.merge(dim_paciente, on="UUID", how="left")
          .merge(dim_ubicacion, left_on="UBIGEO_LUGAR_RESIDENCIA", right_on="Ubigeo", how="left")
          .merge(dim_grupo, left_on="GrupoEtario", right_on="Etiqueta", how="left")
    )
    hechos["SK_Tiempo_Filiacion"] = hechos["FEC_FILIACION"].dt.strftime("%Y%m%d").astype(int)

    tabla_cex = hechos[[
        "SK_Paciente", "SK_Tiempo_Filiacion", "SK_Ubicacion", "SK_GrupoEtario",
        "UUID", "CANT_ATENCIONES_CEX",
    ]].rename(columns={"UUID": "UUID_Origen", "CANT_ATENCIONES_CEX": "Cant_Atenciones_CEX"})

    antes = len(tabla_cex)
    tabla_cex = tabla_cex.dropna(subset=["SK_Paciente", "SK_Ubicacion", "SK_GrupoEtario"])
    if antes - len(tabla_cex) > 0:
        log.warning(f"{antes - len(tabla_cex)} registros de PacientesNuevos sin surrogate key completo -> excluidos.")

    tabla_cex.to_sql("Hechos_AtencionesCEX", engine, schema="dw", if_exists="append", index=False)
    log.info(f"Hechos_AtencionesCEX: {len(tabla_cex)} filas cargadas.")


if __name__ == "__main__":
    inicio = datetime.now()
    log.info(f"=== Inicio de ejecución ETL: {inicio} ===")

    df_egresados, df_nuevos = extraer()
    df_transformado = transformar(df_egresados, df_nuevos)
    limpiar_hechos()
    cargar(df_transformado)
    cargar_atenciones_cex(df_nuevos)

    fin = datetime.now()
    log.info(f"=== Fin de ejecución ETL: {fin} | Duración: {fin - inicio} ===")
