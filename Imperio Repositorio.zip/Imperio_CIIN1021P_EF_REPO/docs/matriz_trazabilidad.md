# Matriz de trazabilidad del proyecto integrador

Los pesos de la rúbrica salen del desafío CIIN1021P (EP: 5 criterios de 4 puntos; EF: 2 + 2 + 2 + 6 + 2 + 6 puntos). El **logro del curso** y la ponderación de cada evaluación dentro de la nota final están en el sílabo y se completan allí.

| Logro del curso | Tema del sílabo | Paso de práctica de campo | Sección del entregable | Criterio de rúbrica | Componente (peso) |
|---|---|---|---|---|---|
| [según sílabo] | Tema 1: Fundamentos avanzados de BD relacionales | Paso 1: Relevamiento | [1.1] Relevamiento y supuestos | Definición del reto, alcance y supuestos | EP (4 pts) |
| [según sílabo] | Tema 2: Automatización y control transaccional | Paso 2: Objetos de automatización | [1.2] Automatización | Fundamentación del método y alternativas | EP (4 pts) |
| [según sílabo] | Tema 2 | Paso 2 | [1.2] Automatización | Automatización con objetos de BD y justificación | EF (2 pts) |
| [según sílabo] | Tema 3: Administración, seguridad y rendimiento | Paso 3: Seguridad y cumplimiento | [1.3] Seguridad Ley N.° 29733 | Seguridad, cumplimiento y consecuencias | EF (2 pts) |
| [según sílabo] | Tema 4: Nuevos paradigmas en el manejo de datos | Paso 4: NoSQL | [1.4] Integración SQL–NoSQL | Validación de viabilidad del componente más incierto | EP (4 pts) |
| [según sílabo] | Tema 5: Inteligencia de negocios y modelado | Paso 5: Data Warehouse y ETL | [1.5] DW y ETL | DW, ETL y justificación Kimball vs Inmon | EF (2 pts) |
| [según sílabo] | Tema 6: Análisis y visualización de datos | Paso 6: Dashboard y OLAP | [1.6] Dashboard, KPIs y OLAP | Claridad y comunicación de resultados con datos | EF (6 pts) |
| [según sílabo] | Tema 7: Ecosistema Big Data y Spark | Paso 7: Spark | [1.7] Big Data con Spark | Claridad y comunicación de resultados con datos | EF (6 pts) |
| [según sílabo] | Temas 1 a 7 | Pasos 1 a 8 (defensa oral) | Sustentación [2.1] a [2.3] | Dominio individual y defensa de decisiones técnicas | EF (6 pts) |
| [según sílabo] | Tema 1 | Paso 8: Reflexión ética | [1.8] Reflexión ética | Argumentación ética sobre consecuencias | EF (2 pts) |
| [según sílabo] | Tema 1 | Paso 8: Integración y articulación | [1.1] y [1.9] | Diagnóstico de riesgos y articulación curricular | EP (4 pts) |
| [según sílabo] | Tema 2 | Paso 8: Repositorio | [1.9] Repositorio | Planificación y ruta del proyecto con hitos | EP (4 pts) |
