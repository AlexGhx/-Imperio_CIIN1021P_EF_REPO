"""
Carga de Egresados (SQL Server) a MongoDB: un documento por paciente con la lista de sus ingresos.
Proyecto DataSalud Perú · CIIN1021P · Grupo Imperio (Capítulo 4, sección 4.3)

Aplica las mismas reglas de limpieza del ETL de 03_BI: elimina duplicados exactos
(UUID + FECHA_INGRESO + FECHA_EGRESO) y excluye los registros sin UUID.

Resultado esperado según el informe: 34,480 pacientes, 54,603 ingresos, 11,593 pacientes con reingreso.

VERIFICAR (borrar esta nota al confirmar): el informe cita este script pero no estaba en el repositorio;
esta versión sigue la descripción de la sección 4.3. Si el equipo conserva el original, reemplazar este archivo.

Requisitos: pip install pandas sqlalchemy pyodbc pymongo
Variables de entorno opcionales: DATASALUD_CONN_STR (SQL Server), MONGO_URI (por defecto mongodb://localhost:27017).
El usuario de SQL Server necesita UNMASK para leer UUID e HISTORIA reales.
"""

import os
import time

import pandas as pd
from pymongo import MongoClient
from sqlalchemy import create_engine

CONN_STR = os.environ.get(
    "DATASALUD_CONN_STR",
    "mssql+pyodbc://@AnghVC\\SQLEXPRESS/baseMINSA"
    "?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes",
)
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")


def construir_documentos(df: pd.DataFrame) -> list[dict]:
    """Limpia los egresos y devuelve un documento por paciente con su lista de episodios."""
    df = df.copy()
    df["FECHA_INGRESO"] = pd.to_datetime(df["FECHA_INGRESO"])
    df["FECHA_EGRESO"] = pd.to_datetime(df["FECHA_EGRESO"])
    df = df.drop_duplicates(subset=["UUID", "FECHA_INGRESO", "FECHA_EGRESO"])
    df = df[df["UUID"].notna()].sort_values(["UUID", "FECHA_INGRESO"])

    documentos = []
    for uuid, grupo in df.groupby("UUID", sort=False):
        primero = grupo.iloc[0]
        documentos.append({
            "uuid": uuid,
            "historia": primero["HISTORIA"],
            "sexo": primero["SEXO"],
            "ubigeo": primero["UBIGEO_LUGAR_RESIDENCIA"],
            "lugar_residencia": primero["LUGAR_RESIDENCIA"],
            "episodios": [
                {
                    "fecha_ingreso": f.FECHA_INGRESO.to_pydatetime(),
                    "fecha_egreso": f.FECHA_EGRESO.to_pydatetime(),
                    "edad": None if pd.isna(f.EDAD) else int(f.EDAD),
                }
                for f in grupo.itertuples()
            ],
        })
    return documentos


if __name__ == "__main__":
    inicio = time.time()
    engine = create_engine(CONN_STR)
    egresados = pd.read_sql("SELECT * FROM dbo.Egresados", engine)
    documentos = construir_documentos(egresados)

    coleccion = MongoClient(MONGO_URI)["datasalud_nosql"]["pacientes_egresados"]
    coleccion.drop()
    coleccion.insert_many(documentos)
    coleccion.create_index("uuid")

    ingresos = sum(len(d["episodios"]) for d in documentos)
    con_reingreso = sum(1 for d in documentos if len(d["episodios"]) > 1)
    print(f"Pacientes (documentos): {len(documentos):,}")
    print(f"Ingresos al hospital: {ingresos:,}")
    print(f"Pacientes con reingreso: {con_reingreso:,}")
    print(f"Tiempo de carga: {time.time() - inicio:.2f} segundos")
