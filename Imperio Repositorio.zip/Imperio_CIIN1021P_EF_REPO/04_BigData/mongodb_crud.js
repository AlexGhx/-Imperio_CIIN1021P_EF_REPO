use("datasalud_nosql");

db.pacientes_egresados.countDocuments({});

db.pacientes_egresados.insertOne({
  uuid: "PRUEBA-CRUD-001",
  historia: "HIST-PRUEBA",
  sexo: "FEMENINO",
  ubigeo: "150101",
  lugar_residencia: "LIMA-LIMA-SAN ISIDRO",
  episodios: [
    { fecha_ingreso: ISODate("2026-09-01"), fecha_egreso: ISODate("2026-09-05"), edad: 30 }
  ]
});
db.pacientes_egresados.find({ uuid: "PRUEBA-CRUD-001" });

db.pacientes_egresados.countDocuments({ "episodios.1": { $exists: true } });

db.pacientes_egresados.find({ lugar_residencia: /SAN ISIDRO/ }).limit(5);

db.pacientes_egresados.aggregate([
  { $project: { uuid: 1, total_ingresos: { $size: "$episodios" } } },
  { $sort: { total_ingresos: -1 } },
  { $limit: 5 }
]);

db.pacientes_egresados.updateOne(
  { uuid: "PRUEBA-CRUD-001" },
  { $push: { episodios: { fecha_ingreso: ISODate("2026-10-01"), fecha_egreso: ISODate("2026-10-04"), edad: 30 } } }
);
db.pacientes_egresados.find({ uuid: "PRUEBA-CRUD-001" });

db.pacientes_egresados.deleteOne({ uuid: "PRUEBA-CRUD-001" });
db.pacientes_egresados.countDocuments({});
