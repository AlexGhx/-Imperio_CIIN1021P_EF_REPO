"""
Carga de PacientesNuevos (SQL Server) a MongoDB: un documento por fila.
Proyecto DataSalud Perú · CIIN1021P · Grupo Imperio (Capítulo 4, sección 4.3)

Resultado esperado según el informe: 78,976 filas leídas y 78,976 documentos guardados.

VERIFICAR (borrar esta nota al confirmar): el informe cita este script pero no estaba en el repositorio;
esta versión sigue la descripción de la sección 4.3 y los nombres de campo son una propuesta (minúsculas,
igual que pacientes_egresados). Si el equipo conserva el original, reemplazar este archivo.

Requisitos: pip install pandas sqlalchemy pyodbc pymongo
Variables de entorno opcionales: DATASALUD_CONN_STR (SQL Server), MONGO_URI (por defecto mongodb://localhost:27017).
El usuario de SQL Server necesita UNMASK para leer UUID e HISTORIA reales.
"""

import os

import pandas as pd
from pymongo import MongoClient
from sqlalchemy import create_engine

CONN_STR = os.environ.get(
    "DATASALUD_CONN_STR",
    "mssql+pyodbc://@AnghVC\\SQLEXPRESS/baseMINSA"
    "?driver=ODBC+Driver+17+for+SQL+Server&trusted_connection=yes",
)
MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")


def construir_documentos(df: pd.DataFrame) -> list[dict]:
    """Un documento por fila de PacientesNuevos."""
    documentos = []
    for f in df.itertuples():
        documentos.append({
            "uuid": f.UUID,
            "historia": f.HISTORIA,
            "fec_filiacion": None if pd.isna(f.FEC_FILIACION) else pd.Timestamp(f.FEC_FILIACION).to_pydatetime(),
            "sexo": f.SEXO,
            "edad": None if pd.isna(f.EDAD) else int(f.EDAD),
            "ubigeo": f.UBIGEO_LUGAR_RESIDENCIA,
            "lugar_residencia": f.LUGAR_RESIDENCIA,
            "cant_atenciones_cex": None if pd.isna(f.CANT_ATENCIONES_CEX) else int(f.CANT_ATENCIONES_CEX),
            "fecha_corte": None if pd.isna(f.FECHA_CORTE) else pd.Timestamp(f.FECHA_CORTE).to_pydatetime(),
        })
    return documentos


if __name__ == "__main__":
    engine = create_engine(CONN_STR)
    nuevos = pd.read_sql("SELECT * FROM dbo.PacientesNuevos", engine)
    print(f"Filas leídas de SQL Server: {len(nuevos):,}")

    documentos = construir_documentos(nuevos)
    coleccion = MongoClient(MONGO_URI)["datasalud_nosql"]["pacientes_nuevos"]
    coleccion.drop()
    coleccion.insert_many(documentos)
    coleccion.create_index("uuid")
    print(f"Documentos guardados en MongoDB: {coleccion.count_documents({}):,}")
